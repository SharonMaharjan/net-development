﻿namespace MvcMovie.DAL
{
    public class UnitOfWork
    {
    }
}
