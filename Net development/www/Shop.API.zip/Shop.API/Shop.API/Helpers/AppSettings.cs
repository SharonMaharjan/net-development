﻿namespace Shop.API.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
